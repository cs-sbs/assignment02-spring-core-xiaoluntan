package org.example.repository;

import org.springframework.core.annotation.Order;

public interface OrderRepository {
    void saveOrder();
}
